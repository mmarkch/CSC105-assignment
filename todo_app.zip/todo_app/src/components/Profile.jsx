import "./Profile.css";
function Profile (){
    return(
        <div className="layout">
            <img src="assets/pizzaaaaa.jpg" alt="profile"/>
            <h1 className="name">Mark Mananchai</h1>
            <hr></hr>
        </div>
    )
}
export default Profile;